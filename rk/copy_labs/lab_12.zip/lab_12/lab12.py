"""
Кузнецов Егор Владимирович ИУ7-13Б
Программа, обеспечивающая работу с базами данных в текстовом файле

Ввод программы:
         - Номер пункта и требуемые данные

Вывод программы:
         - Вывод пункта
"""

def is_int(input: str) -> bool:
    """
    Возвращает True, если число можно привести к int, иначе False
    """
    input = input.replace('_', '')
    is_negative = input[0] == '-'
    if is_negative:
        input = input[1:]
    return input.isdigit()
    
def print_function_list() -> None:
    """
    Выводит список всех функций
    """
    print(
        '1. Выбрать файл для работы',
        '2. Инициализировать базу данных',
        '3. Вывести содержимое базы данных',
        '4. Добавить запись в базу данных',
        '5. Поиск по одному полю',
        '6. Поиск по двум полям',
        '7. Завершить программу',
        sep = '\n'
    )

def get_function_number() -> int:
    """
    Запрашивает у пользователя номер функции и возвращает его
    """
    while True:
        input_str = ''
        while not input_str:
            input_str = input(
                'Введите номер функции, которую вы хотите выполнить: '
            )

        if is_int(input_str):
            if ((len(input_str) - input_str.count('0') > 1 or
                input_str[-1] in '089') or input_str[0] == '-'):
                print('Несуществующий номер, попробуйте ещё раз.')
            else:
                return int(input_str)
        else:
            print(
                'Некорректный ввод, введите только число. Попробуйте ещё раз.'
            )

def get_int(
              input_message: str,
              conditions: list = [],
              error_messages: list = []
              ) -> int:
    """
    Запрашивает у пользователя целое число до того момента 
    как он введёт корректное
    """
    while True:
        str_res = ''
        while not str_res:
            str_res = input(input_message)
        if is_int(str_res):
            t = int(str_res)
            for i in range(len(conditions)):
                if not conditions[i](t):
                    print(error_messages[i])
                    break
            else:
                return t
        else:
            print(
                'Некорректный ввод, введите только число. Попробуйте ещё раз.'
            )

import os
def select_file() -> str:
    """
    Запрашивает название файла, находящегося в той же папке
    или абсолютный путь к файлу
    """
    return input("Введите название файла или полный путь к нему: ")

def init_database(file_name: str) -> None:
    """
    Создаёт или открывает файл по имени
    """
    if file_name == None:
        print("Файл для работы не был указан")
        return
    try:
        file = open(file_name, 'w')
        file.close()
    except:
        print("Файл не может быть открыт или создан")

def get_values(string: str):
    """
    Возвращает массив значений если строка может быть
    расшифрована, иначе возвращает False
    """
    if string == None:
        return False
    splited = string.split('\t')
    if (len(splited) != 4 or
        ((not is_int(splited[1])) or int(splited[1]) <= 0) or
        ((not is_int(splited[2])) or (not 0 < int(splited[2]) <= 4)) or
        len(splited[3]) != 8):
        return False
    result = [ splited[0], int(splited[1]), int(splited[2]), []]
    for i in range(0, len(splited[3]), 2):
        min_dise_value = ord(splited[3][i]) - 20
        max_dise_value = ord(splited[3][i+1]) - 20
        if min_dise_value > max_dise_value:
            return False
        result[3].append((min_dise_value, max_dise_value))
    return result

def print_database(file_name: str) -> None:
    """
    Проверяет файл и выводит его, если тот существует и
    является базой данных
    """
    if file_name == None:
        print("Файл для работы не был указан")
        return 
    if (os.path.exists(file_name) or 
        os.path.exists(os.getcwd() + os.sep + file_name)):
        try:
            file = open(file_name, 'r')
        except:
            print("Файл не может быть открыт")

        max_name_len = 0
        file_empty = True
        for i in file:
            values = get_values(i.rstrip())
            if not i.rstrip():
                continue
            if not values:
                print("Файл не содержит базу данных")
                return
            else:
                if max_name_len < len(values[0]):
                    max_name_len = len(values[0])
                file_empty = False
        if file_empty:
            print("Файл пустой")
            return

        name_len = max(max_name_len + 1, 
                       len("Название карты: "))
        print("Название карты: " + " " * (name_len - len("Название карты: ")) +
              "Количество света: " + "Количество костей: " + 
              "Значения костей: ")
        file.seek(0)
        for i in file:
            if not i.rstrip():
                continue
            cur_line = get_values(i.rstrip())
            print(cur_line[0] + ' ' * (name_len - len(cur_line[0])),
                  '{:^18}'.format(cur_line[1]),
                  '{:^19}'.format(cur_line[2]),
                  *["{:<4}{:<4}".format(
                      *cur_line[3][j]) for j in range(cur_line[2])],
                  sep = ''
                  )


    else:
        print("Файл не существует")
        return

def add_line_to_database(file_name: str) -> None:
    """
    Запрашивает значения для новой строки базы данных и записывает её
    """
    if file_name == None:
        print("Файл для работы не был указан")
        return
    try:
        file = open(file_name, 'a')
    except:
        print("Файл не может быть открыт или создан")
        return
    card_name = ''
    while not card_name:
        card_name = input("Введите название новой карты: ").replace('\t', ' ')
    light_capacity = get_int(
        "Введите количество света для использования карты: ",
        [lambda x: x >= 0],
        ["Количество света должно быть неотрицательным числом. "
         "Попробуйте ещё раз"])
    count_dice = get_int(
        "Введите количество костей (число от 1 до 4): ",
        [lambda x: x > 0, lambda x: x <= 4],
        ["Количество костей должно быть положительным числом. "
         "Попробуйте ещё раз", 
         "Количество костей должно быть не большим чем 4. "
         "Попробуйте ещё раз"])
    dice_values = [(0, 0) for i in range(4)]
    for i in range(count_dice):
        min_value = get_int(
            f"Введите минимальное значение кости {i+1}(число от 1 до 100): ",
            [lambda x: x >= 0, lambda x: x <= 100],
            ["Значение кости должно быть положительным числом. "
             "Попробуйте ещё раз",
             "Значение кости должно быть меньше или равно 100. "
             "Попробуйте ещё раз"]
        )
        max_value = get_int(
            f"Введите максимальное значение кости {i+1}(число от 1 до 100): ",
            [lambda x: x >= 0, 
             lambda x: x <= 100, 
             lambda x: x >= min_value],
            ["Значение кости должно быть положительным числом. "
             "Попробуйте ещё раз",
             "Значение кости должно быть меньше или равно 100. "
             "Попробуйте ещё раз",
             "Значение кости должно быть больше или равно минимального. "
             "Попробуйте ещё раз"]
        )
        dice_values[i] = (min_value, max_value)
    str_dice_values = ''
    for i in dice_values:
        str_dice_values += chr(i[0]+20) + chr(i[1]+20)
    file.write(card_name + '\t' + 
               str(light_capacity) + '\t' + 
               str(count_dice) + '\t' + 
               str_dice_values + '\n')
    file.close()



database_file_name = None
while True:
    print_function_list()
    function_number = get_function_number()
    if function_number == 1:
        database_file_name = select_file()
    elif function_number == 2:
        init_database(database_file_name)
    elif function_number == 3:
        print_database(database_file_name)
    elif function_number == 4:
        add_line_to_database(database_file_name)
    elif function_number == 5:
        find_by_one_field(database_file_name)
    elif function_number == 6:
        find_by_two_fields(database_file_name)
    elif function_number == 7:
        break
    print('\n')